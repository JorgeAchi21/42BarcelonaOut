/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cejulian <cejulian@student.42barcelona.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/12 12:16:53 by cejulian          #+#    #+#             */
/*   Updated: 2023/02/12 14:27:49 by cejulian         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(int x, int y);

int	rush00(int xx, int yy)
{
	ft_putchar(xx, yy);
	return (0);
}
